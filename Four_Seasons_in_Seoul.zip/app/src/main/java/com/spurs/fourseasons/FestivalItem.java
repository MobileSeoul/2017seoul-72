package com.spurs.fourseasons;

/**
 * Created by alfo06-11 on 2017-08-11.
 */

public class FestivalItem {

    String imgUrl;
    String title;

    public FestivalItem(String imgUrl, String title) {
        this.imgUrl = imgUrl;
        this.title = title;
    }
}
